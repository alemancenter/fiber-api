package routes

import (
	"github.com/alemancenter/fiber-api/internal/middleware"
	"github.com/gofiber/fiber/v2"
)

// registerContentRoutes handles all routes related to core content:
// Articles, Posts, Categories, Comments, Files, Keywords, and AI.
func registerContentRoutes(api, public, dash fiber.Router, h *Handlers) {
	// =====================
	// PUBLIC ROUTES
	// =====================

	// Articles
	// Important: Static/specific routes must come before dynamic /:id routes
	public.Get("/articles", h.Articles.List)
	public.Get("/articles/download", h.Articles.DownloadFileSigned)
	public.Get("/articles/by-class/:grade_level", h.Articles.ByClass)
	public.Get("/articles/by-keyword/:keyword", h.Articles.ByKeyword)
	public.Get("/articles/file/:id/download", h.Articles.DownloadFile)
	public.Get("/articles/file/:id/download-url", h.Articles.GetDownloadToken)
	public.Get("/articles/:id", h.Articles.Show)

	// Posts
	public.Get("/posts", h.Posts.List)
	public.Get("/posts/:id", h.Posts.Show)
	public.Post("/posts/:id/increment-view", h.Posts.IncrementView)

	// Categories
	public.Get("/categories", h.Categories.List)
	public.Get("/categories/:id", h.Categories.Show)

	// Comments
	public.Get("/comments/:database", h.Comments.List)

	// Files
	public.Get("/files/:id/info", h.Files.Info)
	public.Post("/files/:id/increment-view", h.Files.IncrementView)

	// Keywords
	public.Get("/keywords", h.Keywords.Index)
	public.Get("/keywords/:keyword", h.Keywords.Show)

	// =====================
	// USER AUTHENTICATED ROUTES
	// =====================
	userRoutes := api.Group("", middleware.Auth(), middleware.UpdateLastActivity())

	// Reactions (Comments)
	userRoutes.Post("/reactions", h.Comments.CreateReaction)
	userRoutes.Delete("/reactions/:comment_id", h.Comments.DeleteReaction)
	userRoutes.Get("/reactions/:comment_id", h.Comments.GetReactions)

	// File upload
	userRoutes.Post("/upload/image", h.Files.UploadImage)
	userRoutes.Post("/upload/file", h.Files.UploadDocument)

	// Secure file view
	userRoutes.Get("/secure/view", h.Files.SecureView)

	// AI generation (User dashboard)
	userRoutes.Post("/ai/generate", h.AI.Generate)

	// =====================
	// ADMIN DASHBOARD ROUTES
	// =====================

	// Articles management
	dashArticles := dash.Group("/articles", middleware.Can("manage articles"))
	dashArticles.Get("/stats", h.Articles.DashboardStats)
	dashArticles.Get("/create", h.Articles.DashboardCreateData)
	dashArticles.Get("", h.Articles.DashboardList)
	dashArticles.Post("", h.Articles.DashboardCreate)
	dashArticles.Get("/:id/edit", h.Articles.DashboardEditData)
	dashArticles.Post("/:id/publish", h.Articles.DashboardPublish)
	dashArticles.Post("/:id/unpublish", h.Articles.DashboardUnpublish)
	dashArticles.Get("/:id", h.Articles.Show)
	dashArticles.Put("/:id", h.Articles.DashboardUpdate)
	dashArticles.Delete("/:id", h.Articles.DashboardDelete)

	// Posts management
	dashPosts := dash.Group("/posts", middleware.Can("manage posts"))
	dashPosts.Post("", h.Posts.DashboardCreate)
	dashPosts.Post("/:id/toggle-status", h.Posts.DashboardToggleStatus)
	dashPosts.Post("/:id", h.Posts.DashboardUpdate)
	dashPosts.Delete("/:id", h.Posts.DashboardDelete)

	// Categories management
	dashCategories := dash.Group("/categories", middleware.Can("manage categories"))
	dashCategories.Get("", h.Categories.DashboardList)
	dashCategories.Post("", h.Categories.DashboardCreate)
	dashCategories.Get("/:id", h.Categories.DashboardShow)
	dashCategories.Post("/:id/update", h.Categories.DashboardUpdate)
	dashCategories.Post("/:id/toggle", h.Categories.DashboardToggleStatus)
	dashCategories.Delete("/:id", h.Categories.DashboardDelete)

	// Comments management
	dashComments := dash.Group("/comments", middleware.Can("manage comments"))
	dashComments.Get("/:database", h.Comments.DashboardList)
	dashComments.Post("/:database", h.Comments.DashboardCreate)
	dashComments.Delete("/:database/:id", h.Comments.DashboardDelete)

	// Files management
	dashFiles := dash.Group("/files", middleware.Can("manage files"))
	dashFiles.Get("", h.Files.DashboardList)
	dashFiles.Post("", h.Files.DashboardUpload)
	dashFiles.Get("/:id/info", h.Files.Info)
	dashFiles.Get("/:id/download", h.Files.DashboardDownload)
	dashFiles.Get("/:id", h.Files.DashboardShow)
	dashFiles.Put("/:id", h.Files.DashboardUpdate)
	dashFiles.Delete("/:id", h.Files.DashboardDelete)

	// Secure file upload (dashboard)
	dash.Post("/secure/upload-image", middleware.Can("upload files"), h.Files.SecureUploadImage)
	dash.Post("/secure/upload-document", middleware.Can("upload files"), h.Files.SecureUploadDocument)

	// AI (dashboard)
	dash.Post("/ai/generate", middleware.Can("manage articles"), h.AI.Generate)
}
